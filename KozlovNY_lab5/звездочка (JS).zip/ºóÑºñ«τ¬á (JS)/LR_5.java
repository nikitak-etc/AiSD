import java.util.Random;
import java.lang.*;
import java.util.ArrayList;
import java.io.*;
import java.util.Scanner;
import java.util.Collections;
import java.util.Arrays;


class Tape{
String path;
int elems;
int serLen;
BufferedWriter writer;
Scanner reader;
boolean isWrite;
boolean isRead;
boolean isEmpty;
boolean isFull;

Tape(String _path) throws IOException{
path=_path;
isEmpty=true;
isFull=false;
isWrite=true;
writeMode();
isRead=false;
elems=0;
serLen=1;
}


void writeMode() throws IOException{
isWrite=true;
FileWriter os = new FileWriter(path);
writer = new BufferedWriter(os);
}


void endWrite() throws IOException{
	isWrite=false;
writer.close();
}


void readMode() throws IOException{
	isRead=true;
File is = new File(path);
reader = new Scanner(is);
}


void endRead() throws IOException{
	isRead=false;
	if(reader!=null)
	reader.close();
}

void addNum(int num) throws IOException{
	isEmpty=false;
if(!isWrite) writeMode();
writer.write(Integer.toString(num) + " ");
elems++;
}


void clearFile() throws IOException{
	isEmpty=true;
File fl=new File(path);
fl.delete();
File fn=new File(path);
fn.createNewFile();
}

int readNum() throws IOException{
	if(!isRead) readMode();
	elems--;
	int num = reader.nextInt();
	if(elems==0) clearFile();
	return num;
}

}

class sortCell{
	int series, serLen;
	sortCell(int _series, int _serLen){
		series=_series; serLen=_serLen;
	}
}



class LR_5{

static int[] arr10_F,    arr10_B,    arr10_R,
	  		 arr500_F,   arr500_B,   arr500_R,
	  		 arr10000_F, arr10000_B, arr10000_R;

static String Sarr10_F,    Sarr10_B,    Sarr10_R,
	  		  Sarr500_F,   Sarr500_B,   Sarr500_R,
	  		  Sarr10000_F, Sarr10000_B, Sarr10000_R;

static int compares =0;
static int swaps    =0;
static long start_time;
static long end_time;


static int[] genF(int n){
	int[] arr = new int[n];
	for(int i=0; i<n; i++) arr[i]=i;
	return arr;
}

static int[] genB(int n){
	int[] arr = new int[n];
	for(int i=0; i<n; i++) arr[i]=n-i-1;
	return arr;	
}


static int[] genR(int n){
	int[] arr = new int[n];
	Random r = new Random();
	arr = r.ints(n, 0, n).toArray();
	return arr;
}

static void printArr(int[] arr){
	for(int i=0; i<arr.length; i++) System.out.print(arr[i] + " ");
		System.out.println();
}



static void writeToFile(int[] arr, String file) throws IOException{
FileWriter os = new FileWriter(file);
BufferedWriter bos = new BufferedWriter(os);

for(int i=0; i<arr.length-1; i++) bos.write(Integer.toString(arr[i]) + " ");
bos.write(Integer.toString(arr[arr.length-1]));
bos.close();
}

//DATA GENERATION


static void initialize(String[] args) throws IOException{
Sarr10_R=args[0];
Sarr10_B=args[1];
Sarr10_F=args[2];

Sarr500_R=args[3];
Sarr500_B=args[4];
Sarr500_F=args[5];

Sarr10000_R=args[6];
Sarr10000_B=args[7];
Sarr10000_F=args[8];


arr10_R = genR(10);
writeToFile(arr10_R, Sarr10_R);
arr10_B = genB(10);
writeToFile(arr10_B, Sarr10_B);
arr10_F = genF(10);
writeToFile(arr10_F, Sarr10_F);

arr500_R = genR(500);
writeToFile(arr500_R, Sarr500_R);
arr500_B = genB(500);
writeToFile(arr500_B, Sarr500_B);
arr500_F = genF(500);
writeToFile(arr500_F, Sarr500_F);


arr10000_R = genR(10000);
writeToFile(arr10000_R, Sarr10000_R);
arr10000_B = genB(10000);
writeToFile(arr10000_B, Sarr10000_B);
arr10000_F = genF(10000);
writeToFile(arr10000_F, Sarr10000_F);
}

//DATA GENERATION

//FILE METADATA PROCESSING

static String ctlg(String id){
String[] data = id.split("/");
return data[0];
}

static String dirct(String id){
String[] data = id.split("/");
return data[1];
}

static String parseTapePath(String id, int num){
	String tapeName = "";
	tapeName+=dirct(id)+"_T"+Integer.toString(num);
	return ctlg(id)+"/"+tapeName;
}

static String setTape(String id, int num) throws IOException{
String tapeName = parseTapePath(id, num);
File file = new File(tapeName);
file.createNewFile();
return tapeName;
}

static Tape[] initializeTapes(String file) throws IOException{
Tape[] tapes = new Tape[5];
for(int i=0; i<5; i++){
Tape tp = new Tape(setTape(file, i));
tapes[i]=tp;
}
return tapes;
}

//FILE METADATA PROCESSING


static void firstDistribution(String file, Tape[] tapes, int[] distrib, int elems) throws IOException{
	//System.out.println("Code working");
File is = new File(file);
Scanner sc = new Scanner(is);

int num=0;
int index=0;

int del = arrSumm(distrib)-elems;

int div=0;
for(int i=0; i<distrib.length; i++){
	div=distrib.length-i;
	// System.out.println(del +" "+ div);
	//System.out.println((int)Math.round((float)del/(float)div));

	for(int j=0; j<(int)Math.round((float)del/(float)div); j++){
		swaps++; //FIO OPERATON
		tapes[i].addNum(-2);
		swaps++; //FIO OPERATON
		tapes[i].addNum(-5);
		distrib[i]-=1;
	}
	while(distrib[i]>0){
		swaps+=2; //FIO OPERATON
		tapes[i].addNum(sc.nextInt());
		swaps++; //FIO OPERATON
		tapes[i].addNum(-5);
		distrib[i]-=1;
	}
	del-=(int)Math.round((float)del/(float)div);
}


for(int i=0; i<4; i++){
		tapes[i].endWrite();
		tapes[i].serLen=1;
	}

	sc.close();

}



static int minInd(int[] arr){
if(arr[0]<=arr[1] && arr[0] <=arr[2]) return 0;
else if(arr[1]<=arr[0] && arr[1] <=arr[2]) return 1;
else return 2; 
}


static int findEmpty(Tape[] tapes){
for(int i=0; i<5; i++){
	if(tapes[i].isEmpty) return i;
}
return -1;
}

static int minind(int[] arr){
	int min=Integer.MAX_VALUE;
	int minInd=0;
	for(int i=0; i<arr.length; i++){
		compares++;
		if(arr[i]<=min && arr[i]!=-3 && arr[i]!=-5){min=arr[i]; minInd=i;}
	}
	if(min==Integer.MAX_VALUE) return-3;
	return minInd;
}


static int maxind(int[] arr){
	int min=-3;
	int minInd=0;
	for(int i=0; i<arr.length; i++){
		if(arr[i]>=min && arr[i]!=-3){min=arr[i]; minInd=i;}
	}
	return minInd;
}

static int[] nextSeries(int[] arr){
	for(int i=0; i<arr.length; i++)
		arr[i]=-3;
	return arr;
}

static boolean isSeriesEnded(int[] arr){
	for(int i=0; i<arr.length; i++) if(arr[i]!=-5) return false;
		return true;
}

static boolean isSeriesReturned(int[] arr){
	for(int i=0; i<arr.length; i++) if(arr[i]!=-3) return false;
		return true;
}

static boolean endOfMerge=false;

static boolean isFinished(Tape[] tapes){
	int counter=0;
	for(int i=0; i<5; i++)
		if(tapes[i].isEmpty) counter++;
	if(counter==4){endOfMerge=true; return true;}
	return false;
}

static Tape[] doCascade(Tape[] tapes)throws IOException{

int empty;
int[] readed;
for(int i=4; i>0; i--){ //Merging from 4 files => from last one file
if(isFinished(tapes)) break;


empty = findEmpty(tapes); // merging to empty file
// System.out.println("Empty: " + empty);
readed = new int[i]; // Store one element from each merging file
for(int j=0; j<i; j++) readed[j]=-3; //Mark: from file i should be readed number
while(findEmpty(tapes)==empty || findEmpty(tapes)==-1){ // while there are not occurd new empty element
	while(true){
	int counter =0;
	int minInd=0;
for(int j=0; j<tapes.length; j++){
	if(j==empty || tapes[j].isFull) continue; // we are not merging from merge destination and from already merged files
	if(readed[counter]==-3) {readed[counter]=tapes[j].readNum(); swaps++;} //FIO OPERATON
	counter++;
}

if(!isSeriesEnded(readed)){
minInd = minind(readed);
// System.out.println("Writing " + readed[minInd] + " to " + empty);
tapes[empty].addNum(readed[minInd]); swaps++; //FIO OPERATON
readed[minInd]=-3;
}

else{
// printArr(readed);
nextSeries(readed);
tapes[empty].addNum(-5); swaps++; //FIO OPERATON
break;
}
}
}



tapes[empty].isFull=true; //mark merged file
tapes[empty].endWrite();
empty = findEmpty(tapes);
}

for(int i=0;i<tapes.length; i++){tapes[i].isFull=false; tapes[i].endWrite();}

return tapes;
}

static void setUpTapes(Tape[] tapes)throws IOException{
for(int i=0; i<tapes.length; i++){
	// System.out.println(tapes[i].elems);
	tapes[i].endRead();
	tapes[i].endWrite();
}
}

static void writeResult(String file, Tape[] tapes)throws IOException{
int notEmpty=0;
for(int i=0; i<5; i++) if(!tapes[i].isEmpty){notEmpty=i; break;}
String resFile = ctlg(file) + "/" + dirct(file)+"_RES";

//System.out.println(notEmpty);
//System.out.println(resFile);

 FileWriter os = new FileWriter(resFile);
 BufferedWriter bos = new BufferedWriter(os);

 int num=0;
 while((num=tapes[notEmpty].readNum())!=-5){
 if(num==-2) continue;
 bos.write(Integer.toString(num) + " ");
 }

 bos.close();


}



static void cascadeSort(String file, int elems) throws IOException{
Tape[] tapes = initializeTapes(file);
firstDistribution(file, tapes, primaryDivision(elems, 4), elems);

endOfMerge=false;

while(endOfMerge!=true){
 tapes=doCascade(tapes);
 setUpTapes(tapes);}

writeResult(file, tapes);


}


public static int arrSumm(int[] arr){
	int summ=0;
	for(int i: arr) summ+=i;
		return summ;
}

public static int[] copy(int[] arr){
	int[] narr = new int[arr.length];
	for(int i=0; i<arr.length; i++) narr[i]=arr[i];
		return narr;
}

public static int[] primaryDivision(int elems, int files){
	int[] prevStage = new int[files];
	prevStage[0]=1;
	for(int i=1; i<prevStage.length; i++) prevStage[i]=0;

	int[] currStage = new int[files];
	for(int i=0; i<prevStage.length; i++) currStage[i]=0;

		int summ=0;
	while(arrSumm(currStage)<elems){
		summ=0;
		for(int i=0; i<prevStage.length; i++){
			summ+=prevStage[i];
			currStage[currStage.length-1-i]=summ;
		}
		prevStage=copy(currStage);
		}
		return prevStage;
	}

public static int emptySeries(int[] series, int elems){
	return arrSumm(series)-elems;
}



public static void cascadeMetrix(String file, int elems) throws IOException{
		swaps=0;
		compares=0;
		start_time = System.nanoTime();
		cascadeSort(file, elems);
		end_time = System.nanoTime();
		long time = end_time-start_time;
		System.out.println(file + "\ncompares: " + compares + "\nFILE I/O operations: " + swaps + "\ntime: " + time +"\n");
}


public static void main(String[] args) throws IOException{
initialize(args);


cascadeMetrix(Sarr10_F,10);
cascadeMetrix(Sarr10_B,10);
cascadeMetrix(Sarr10_R,10);

cascadeMetrix(Sarr500_F,500);
cascadeMetrix(Sarr500_B,500);
cascadeMetrix(Sarr500_R,500);

cascadeMetrix(Sarr10000_F,10000);
cascadeMetrix(Sarr10000_B,10000);
cascadeMetrix(Sarr10000_R,10000);


}}