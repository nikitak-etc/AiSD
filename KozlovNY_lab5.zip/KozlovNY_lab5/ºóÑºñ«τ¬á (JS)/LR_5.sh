javac LR_5.java
java LR_5 10/R 10/D 10/I 500/R 500/D 500/I 10000/R 10000/D 10000/I
read -p "..."